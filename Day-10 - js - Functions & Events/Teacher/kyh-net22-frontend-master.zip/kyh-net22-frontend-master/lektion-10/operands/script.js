/*
    OPERANDER
    -------------------------------
    ==      lika med
    ===     lika med och samma datatyp
    !=      inte lika med
    !==     inte lika med och inte samma datatyp
    <       mindre än
    >       större än
    <=      mindre eller lika med
    >=      större eller lika med
    &&      och
    ||      eller
    !       inte
    (??      null-coalescing) finns i C#
    (??=     null-coalescing) finns i C#

*/