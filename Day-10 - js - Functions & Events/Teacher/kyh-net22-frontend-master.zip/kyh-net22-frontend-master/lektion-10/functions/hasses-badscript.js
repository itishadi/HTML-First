function welcomeMessage(name) {
    console.log(`du är inte välkommen här ${name}`)
}