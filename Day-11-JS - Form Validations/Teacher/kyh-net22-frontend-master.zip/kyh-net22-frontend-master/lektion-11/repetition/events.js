function validate(e) {
    console.log(e.target.value)
}

/*
document.getElementById("lastName").addEventListener("change", (e) => {
    validate(e)
})

document.getElementById("firstName").addEventListener("change", (e) => {
    console.log(e.target.value)
})

*/